
const mongoose = require("mongoose");

const PatientSchema = new mongoose.Schema({
  name: String,
  age: Number,
  diagnosis: String,
  vitals: {
    temperature: Number,
    pulse: Number,
    bloodPressure: String
  },
  lastVisit: Date
});

module.exports = mongoose.model("Patient", PatientSchema);
