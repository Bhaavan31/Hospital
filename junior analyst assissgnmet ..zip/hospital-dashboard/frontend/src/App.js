
import React, { useEffect, useState } from "react";
import axios from "axios";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts";

function App() {
  const [patients, setPatients] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/patients")
      .then(res => setPatients(res.data));
  }, []);

  return (
    <div className="App">
      <h1>Patient Dashboard</h1>
      {patients.map((patient, i) => (
        <div key={i}>
          <h3>{patient.name}</h3>
          <p>Diagnosis: {patient.diagnosis}</p>
          <LineChart width={400} height={200} data={[patient.vitals]}>
            <CartesianGrid stroke="#ccc" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="temperature" stroke="#8884d8" />
            <Line type="monotone" dataKey="pulse" stroke="#82ca9d" />
          </LineChart>
        </div>
      ))}
    </div>
  );
}

export default App;
